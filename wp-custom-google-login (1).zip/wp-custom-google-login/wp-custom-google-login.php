<?php 

/**
* Plugin Name: Wp Google Custom Login
* Plugin URI: 
* Description: This plugins will create custom post type.
* Version: 1.0
* Author: Metacube
* Author URI: 
**/


if(!defined('ABSPATH')){
       header("location:/demoProject");
       //die("Can't access");
}

require_once 'google-api/vendor/autoload.php';

$gClient =  new Google_Client();
$gClient->setClientId("586278101876-rfq2k585ukt32cj20gnei3fam13g3qq1.apps.googleusercontent.com");
$gClient->setClientSecret("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");
$gClient->setApplicationName("Web client ");
$gClient->setRedirectUri("https://localhost/demoProject/wp-admin/admin-ajax.php?action=vm_login_google");
$gClient->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");

// login URL
$login_url = $gClient->createAuthUrl();

//create shortcode 

add_shortcode('google-login','vn_login_with_google');
function vn_login_with_google(){
global $login_url; 
$btnContent = '<style>
.googleBtn{
       display:table;
       margin:0 auto;
       background:#4285F4;
       padding:15px;
       border-radius:3px;
       color:#FFF;

}
</style>';

if(!is_user_logged_in()){
       // check if registration is closed 
       if(!get_option('users_can_register')){
              return('Registration is closed!');
       }else{
              return $btnContent . '<a href="'.$login_url.'" class="googleBtn">Login with Gogle</a>';
       }
} else{
       $current_user = wp_get_current_user();
       return $btnContent .'<div class="googleBtn">Hi, '.$current_user->first_name.'! - <a href="'. wp_logout_url(home_url()) .'">Log Out</a></div>';
}
}

//add ajax action
add_action('wp_ajax_vm_login_google', 'vm_login_google');
function vm_login_google(){
       global $gClient;
       if(isset($_GET['code'])){
            $token = $gClient->fetchAccessTokenWithAuthCode($_GET['code']);
             if(!isset($token["error"])){
                    //get data from Google
                    $oAuth = new Google_Service_Oauth2($gClient); 
                    $userData =  $oAuth->userinfo_v2_me->get();
                  
                    // check email already 
                    if(!email_exists($userData->email)){
                           // create pass
                           $bytes = openssl_random_pseudo_bytes(2);
                           $password = md5(bin2hex($bytes));
                           $user_login = $userData->id;

                           $new_user_id = wp_insert_user(array(
                            'user_login' => $user_login,
                            'user_pass' => $password,
                            'user_email' => $userData->email,
                            'first_name' => $userData->givenName,
                            'last_name' => $userData->familyName,
                            'user_registered' => date('Y-m-d H:i:s'),
                            'role' => 'subscriber'
                           ));
                          
                        

                           if($new_user_id){
                                  //send email to admin
                                  wp_new_user_notification($new_user_id);
                            
                         
                                  //log new user in

                                  do_action('wp_login', $user_login, $userData->email);
                                  wp_set_current_user($new_user_id);
                                  wp_set_auth_cookie($new_user_id, true);

                                  //send user to home page
                                  wp_redirect(home_url().'/front-dashboard'); exit;
                           }
                    } else{
                           //if user alredy register then we are just loggin in the user
                           $user = get_user_by('email', $userData->email);
                           add_action('wp_login', $user->user_login, $user->user_email);
                           wp_set_current_user($user->ID);
                           wp_set_auth_cookie($user->ID, true);
                           wp_redirect(home_url().'/front-dashboard'); exit;

                    }
             }else{
                    wp_redirect(home_url());
                    exit;
             }
              
       }
}

//allow Logged out users to access admin-ajax.php action

function add_google_ajax_actions(){
       add_action('wp_ajax_nopriv_vm_login_google', 'vm_login_google');
       }
       
       add_action('admin_init', 'add_google_ajax_actions');

















// admin page view

function cudtom_google_login_admin_page(){
?>     
     <h1>Google Login here</h1>

<?php }
       
      function my_gogle_login_admin_menu() {
            add_menu_page(
    'Google Login View', 
    'Google Login', 
    'manage_options', 
    'myplugin/View_Customer_login_Details.php', 
    'cudtom_google_login_admin_page', 
    'dashicons-tag', 25  );
     }

add_action('admin_menu', 'my_gogle_login_admin_menu' );

// end of  admin page view


/// style and js //////

function my_custom_google_login_scripts(){
       //js
       $path_script = plugins_url('style/js/main.js', __FILE__);
       $dep_script = array('jquery');
       $ver_script = filemtime(plugin_dir_path(__FILE__).'style/js/main.js');
       wp_enqueue_script('my-custom-login-js', $path_script, $dep_script, $ver_script, true);
       
       //css
       $path_css = plugins_url('style/css/CPT-style.css', __FILE__);
       $ver_css = filemtime(plugin_dir_path(__FILE__).'style/css/CPT-style.css');
       wp_enqueue_style('my-custom-login-css', $path_css, $ver_css, );


       }
       
     
       add_action('admin_enqueue_scripts','my_custom_google_login_scripts'); // load for back-end

?>