<?php 

/*
Silence is golden
*/

if(!defined('ABSPATH')){
  header("location:/demoProject");

}

?>